import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    while True:
        city = input("city name:")
        if city not in ('chicago', 'new york city', 'washington'):
            print("Not an appropriate choice.hint! enter lowercase letters")
            continue
        else:
            break
   # get user input for month (all, january, february, ... , june)
    while True:
        month = input("month name(you can choose all):")
        if month not in ('all', 'january', 'february', 'march', 'april', 'may', 'june'):
            print("Not an appropriate choice.hint! enter lowercase letters")
            continue
        else:
            break

    # get user input for day of week (all, monday, tuesday, ... sunday)
    while True:
        day = input("day name(you can choose all):")
        if day not in ('all', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday','sunday'):
            print("Not an appropriate choice.hint! enter lowercase letters")
            continue
        else:
            break

    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    df = pd.read_csv(CITY_DATA[city])
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.day_name()



    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    common_month = df['month'].mode()[0]
    print('Most Common month:', common_month)

    # display the most common day of week
    common_day = df['day_of_week'].mode()[0]
    print('Most Common day:', common_day)


    # display the most common start hour
    df['hour'] = df['Start Time'].dt.hour
    common_hour = df['hour'].mode()[0]

    print('Most Common Start Hour:', common_hour)


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    common_start_station = df['Start Station'].mode()[0]
    print('Most Common start station:', common_start_station)


    # display most commonly used end station
    common_end_station = df['End Station'].mode()[0]
    print('Most Common end station:', common_end_station)


    # display most frequent combination of start station and end station trip
    frequent_combination = df.groupby(['Start Station','End Station']).size().nlargest(1)
    print('most frequent combination of start station and end station trip:', frequent_combination)



    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    total_travel_time = df['Trip Duration'].sum()
    print("total travel time:", total_travel_time)


    # display mean travel time
    avg_travel_time = df['Trip Duration'].mean()
    print("average travel time:", avg_travel_time)



    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    user_types = df['User Type'].value_counts()
    print("user type:", user_types)



    # Display counts of gender
    while True:
        try:
            user_gender = df['Gender'].value_counts()
            print("user gender:", user_gender) 
            break
        except:
            print('there\'s no available data about the gender')  
            break      



    # Display earliest, most recent, and most common year of birth
    while True:
        try:
            recent_year = df['Birth Year'].max()
            common_year = df['Birth Year'].mode()[0]
            print('recent and most common years of birth are:'+ str(int(recent_year))+" and "+ str(int(common_year)))
            break
        except:
            print('there\'s no available date about date birth')   
            break 


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def display_data(df):
        user_input = input('do you want to see raw data?')

        if user_input.lower() == 'yes':
            i= 0
            while i <5:
                raw_data = df.iloc[i]
                print(raw_data)
                i= i+1
                
            return (display_data(df))
        else:
            print('Thanks for your time ')    
 

            

       
def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
        display_data(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
